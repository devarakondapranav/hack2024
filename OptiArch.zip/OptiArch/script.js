// Add your JavaScript functionality here
document.addEventListener('DOMContentLoaded', () => {
    // Example: Click event for Create New button
    document.querySelector('.btn-success').addEventListener('click', () => {
        //alert('Create New Project button clicked!');
    });
});
